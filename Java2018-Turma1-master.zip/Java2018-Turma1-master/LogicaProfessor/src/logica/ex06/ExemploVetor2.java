package logica.ex06;

import br.senai.sp.info132.console.Programa;

public class ExemploVetor2 extends Programa {
	@Override
	public void inicio() {
		double[] vendas;

		int numVendedores = leInteiro("Informe o nº de vendedores");

		if (numVendedores > 0) {
			vendas = new double[numVendedores];
			for (int vendedor = 0; vendedor < vendas.length; vendedor++) {
				vendas[vendedor] = leReal("Informe o valor das Vendas para o ", 
						vendedor + 1, "º vendedor");
			}
			
			int vendedor = 0;
			while(vendedor < vendas.length) {
				double bonus = vendas[vendedor] * 0.02;
				
				escrevaL("O bonus para o ", vendedor + 1,"º vendedor é de R$ ",bonus);
				
				vendedor++;
			}
		}
	}
}
