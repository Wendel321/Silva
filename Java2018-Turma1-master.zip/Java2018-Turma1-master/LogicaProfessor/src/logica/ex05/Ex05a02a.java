package logica.ex05;

import br.senai.sp.info132.console.Programa;

public class Ex05a02a extends Programa {
	@Override
	public void inicio() {
		int analista = 0, programador = 0, usuario = 0, gestor = 0, outro = 0;
		String funcao = leTexto("Informe a Função");

		while (!funcao.equals("fim")) {
			if (funcao.equals("analista")) {
				analista++;
			} else if (funcao.equals("programador")) {
				programador++;
			} else if (funcao.equals("usuario")) {
				usuario++;
			} else if (funcao.equals("gestor")) {
				gestor++;
			} else {
				outro++;
			}
			
			funcao = leTexto("Informe a Função");
		}
		escrevaL("Analista: ", analista, "\nProgramador: ", programador,
				"\nUsuário: ", usuario, "\nGestor: ", gestor, "\nOutro: ", outro );
	}
}
