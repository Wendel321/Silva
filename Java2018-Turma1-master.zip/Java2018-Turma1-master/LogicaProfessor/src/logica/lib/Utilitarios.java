package logica.lib;

public class Utilitarios {
	public static void ordena(int[] valor) {
		boolean trocou;
		do {
			trocou = false;
			for (int i = 0; i < valor.length - 1; i++) {
				if(valor[i] > valor[i+1]) {
					int aux = valor[i+1];
					valor[i+1] = valor[i];
					valor[i] = aux;
					trocou = true;
				}
			}
		} while(trocou);

	}

	public static int[] aumentaTamanho(int[] vetor) {
		return aumentaTamanho(vetor, 5);
	}
	
	public static int[] aumentaTamanho(int[] vetor, int incremento) {
		int[] novo = new int[vetor.length+incremento];
		
		for (int i = 0; i < vetor.length; i++) {
			novo[i] = vetor[i];
		}
		return novo;
	}
	
}
