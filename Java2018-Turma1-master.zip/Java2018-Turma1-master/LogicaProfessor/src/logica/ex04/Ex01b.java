package logica.ex04;

import br.senai.sp.info132.console.Programa;

public class Ex01b extends Programa {
	@Override
	public void inicio() {
		double media = 0;
		
		for (int nota = 1;nota <= 4; nota++) {
			media += leInteiro("Informe a ",nota , "ª nota");
		}
		
		media /= 4;
		
		escreva("Média: ", media, " ");
		
		if(media >= 7) {
			escrevaL("Aprovado");
		} else {
			escrevaL("Reprovado");
		}
	}
}
