package logica.ex04;

import javax.swing.JOptionPane;

public class Ex04XXX {
	public static void main(String[] args) {
		String nome = JOptionPane.showInputDialog("Informer seu Nome");
				
		String temp = JOptionPane.showInputDialog("Informe a 1ª nota");
		int nota1 = Integer.parseInt(temp);
		
		temp = JOptionPane.showInputDialog("Informe a 2ª nota");
		int nota2 = Integer.parseInt(temp);
		
		temp = JOptionPane.showInputDialog("Informe a 3ª nota");
		int nota3 = Integer.parseInt(temp);
		double media = (nota1 + nota2 + nota3) / 3;
		
		temp = JOptionPane.showInputDialog("Informe o nº de faltas");
		int faltas = Integer.parseInt(temp);
		
		String msg = nome + ", você foi: ";
		
		if(faltas > 15) {
			msg += "Reprovado por Faltas" ;
		} else if(media < 7) {
			msg += "Reprovado por Média";
		} else {
			msg += "Aprovado";
		}
		
		JOptionPane.showMessageDialog(null, msg);
	}
}
