package logica.ex03;

import br.senai.sp.info132.console.Programa;

public class Ex06 extends Programa {
	@Override
	public void inicio() {
		int idade = leInteiro("Informe a sua Idade");
		
		String categoria;
		
		if(idade <= 10) {
			categoria = "Infantil";
		} else if(idade < 15) {
			categoria = "Infanto";
		} else if(idade <= 18) {
			categoria = "Juvenil";
		} else {
			categoria = "Adulto";
		}
		
		escrevaL("A sua categoria é ", categoria);
	}
}
