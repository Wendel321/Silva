package logica.ex02;

import br.senai.sp.info132.console.Programa;

/*
 *  Criar um programa para determinar o nome do mês
 *  a partir de um nº, se o nº for inválido apresentar
 *  mensagem de erro
 * 
 */

public class ExemploSwitch extends Programa {
	@Override
	public void inicio() {
		int numero = leInteiro("Informe o nº do mês");
		String mes;
		
		switch (numero) {
		case 1: mes = "Janeiro"; break;
		case 2: mes = "Fevereiro"; break;
		case 3: mes = "Março"; break;
		case 4: mes = "Abril"; break;
		case 5: mes = "Maio"; break;
		case 6: mes = "Junho"; break;
		case 7: mes = "Julho"; break;
		case 8: mes = "Agosto"; break;
		case 9: mes = "Setembro"; break;
		case 10: mes = "Outubro"; break;
		case 11: mes = "Novembro"; break;
		case 12: mes = "Dezembro"; break;
		default: mes = "Inválido"; break;
		}
		
		escreva("O mês é " , mes);
	}
}
